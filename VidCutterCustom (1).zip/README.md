# VidCutterCustom

Custom version with format export + aspect ratio selection.